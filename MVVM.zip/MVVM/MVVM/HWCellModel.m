//
//  HWCellModel.m
//  MVVM
//
//  Created by kgc－mac on 17/7/3.
//  Copyright © 2017年 kgc－mac. All rights reserved.
//

#import "HWCellModel.h"

@implementation HWCellModel

- (id)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (id)HWInfoWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}


@end
