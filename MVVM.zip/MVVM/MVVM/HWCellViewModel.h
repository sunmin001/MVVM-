//
//  HWCellViewModel.h
//  MVVM
//
//  Created by kgc－mac on 17/7/3.
//  Copyright © 2017年 kgc－mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWTableViewCell.h"
#import <UIKit/UIKit.h>

@interface HWCellViewModel : NSObject

@property (nonatomic, strong) NSMutableArray *HWInfoArray;

- (NSInteger)numberOfSections;
- (NSInteger)numberOfItemsInSection:(NSInteger)section;
- (NSString *)titleForHeaderInSection:(NSInteger)section;
- (NSString *)titleForFooterInSection:(NSInteger)section;
- (HWTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@end


