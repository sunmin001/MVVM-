//
//  HWTableViewCell.h
//  MVVM
//
//  Created by kgc－mac on 17/7/3.
//  Copyright © 2017年 kgc－mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HWCellModel;

@interface HWTableViewCell : UITableViewCell

@property (nonatomic, weak) UILabel *lable;
@property (nonatomic, strong) HWCellModel *model;

+ (instancetype)cellWIthTableView:(UITableView *)tableView;  

@end
