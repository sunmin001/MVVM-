//
//  ViewController.m
//  MVVM
//
//  Created by kgc－mac on 17/7/3.
//  Copyright © 2017年 kgc－mac. All rights reserved.
//

#import "ViewController.h"

#include "HWTableTableViewController.h"

@interface ViewController ()

@property (nonatomic,strong)HWTableTableViewController *tableViewController;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.tableViewController = [[HWTableTableViewController alloc] initWithStyle:UITableViewStylePlain];
    self.tableViewController.view.frame = CGRectMake(0, 0, 375, 500);
    [self.view addSubview:self.tableViewController.view];
}

- (void)pushViewController
{}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
