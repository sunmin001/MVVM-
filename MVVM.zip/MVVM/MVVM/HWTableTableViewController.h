//
//  HWTableTableViewController.h
//  MVVM
//
//  Created by kgc－mac on 17/7/3.
//  Copyright © 2017年 kgc－mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HWTableTableViewController : UITableViewController

- (void)pushViewController;

@end
