//
//  HWCellModel.h
//  MVVM
//
//  Created by kgc－mac on 17/7/3.
//  Copyright © 2017年 kgc－mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HWCellModel : NSObject

@property (nonatomic, copy) NSString *image;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subTitle;

- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)HWInfoWithDictionary:(NSDictionary *)dict;

@end
